<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://www.dbuggers.com
 * @since             1.0.0
 * @package           Tokenminds_Academy
 *
 * @wordpress-plugin
 * Plugin Name:       TokenMinds Academy
 * Plugin URI:        https://tokenminds.co
 * Description:       This is the official plugins for TokenMinds Academy. This plugin will helps Tokenminds dashboard to add new custom post type called Academy.
 * Version:           1.0.0
 * Author:            Delower Hossain
 * Author URI:        https://www.dbuggers.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       tokenminds-academy
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'TOKENMINDS_ACADEMY_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-tokenminds-academy-activator.php
 */
function activate_tokenminds_academy() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-tokenminds-academy-activator.php';
	Tokenminds_Academy_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-tokenminds-academy-deactivator.php
 */
function deactivate_tokenminds_academy() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-tokenminds-academy-deactivator.php';
	Tokenminds_Academy_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_tokenminds_academy' );
register_deactivation_hook( __FILE__, 'deactivate_tokenminds_academy' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-tokenminds-academy.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_tokenminds_academy() {

	$plugin = new Tokenminds_Academy();
	$plugin->run();

}
run_tokenminds_academy();


//TokenMinds Academy

function cptui_register_my_cpts() {

	/**
	 * Post Type: Academy.
	 */

	$labels = [
		"name" => esc_html__( "Academy", "astra-child" ),
		"singular_name" => esc_html__( "Academy", "astra-child" ),
		"menu_name" => esc_html__( "Academy", "astra-child" ),
		"all_items" => esc_html__( "All Lessons", "astra-child" ),
		"add_new" => esc_html__( "Add New Lesson", "astra-child" ),
		"add_new_item" => esc_html__( "Add New Lesson", "astra-child" ),
		"edit_item" => esc_html__( "Edit Lesson", "astra-child" ),
		"new_item" => esc_html__( "New Lesson", "astra-child" ),
		"view_item" => esc_html__( "View Lesson", "astra-child" ),
		"view_items" => esc_html__( "View Lessons", "astra-child" ),
		"search_items" => esc_html__( "Search Lessons", "astra-child" ),
		"not_found" => esc_html__( "No Lessons found", "astra-child" ),
		"featured_image" => esc_html__( "Featured image for this lesson", "astra-child" ),
		"set_featured_image" => esc_html__( "Set featured image for this lesson", "astra-child" ),
		"archives" => esc_html__( "Lesson archive", "astra-child" ),
	];

	$args = [
		"label" => esc_html__( "Academy", "astra-child" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"rest_namespace" => "wp/v2",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => true,
		"can_export" => true,
		"rewrite" => [ "slug" => "academy", "with_front" => true ],
		"query_var" => true,
		"menu_position" => 5,
		"menu_icon" => "dashicons-editor-paste-word",
		"supports" => [ "title", "editor", "thumbnail", "excerpt", "trackbacks", "custom-fields", "revisions", "author", "post-formats" ],
		"taxonomies" => [ "category", "post_tag" ],
		"show_in_graphql" => false,
	];

	register_post_type( "academy", $args );
}

add_action( 'init', 'cptui_register_my_cpts' );
