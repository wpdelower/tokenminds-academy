<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.dbuggers.com
 * @since      1.0.0
 *
 * @package    Tokenminds_Academy
 * @subpackage Tokenminds_Academy/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Tokenminds_Academy
 * @subpackage Tokenminds_Academy/includes
 * @author     Delower Hossain <delowerjes@gmail.com>
 */
class Tokenminds_Academy_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
