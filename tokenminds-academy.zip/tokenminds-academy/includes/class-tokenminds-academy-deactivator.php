<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.dbuggers.com
 * @since      1.0.0
 *
 * @package    Tokenminds_Academy
 * @subpackage Tokenminds_Academy/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Tokenminds_Academy
 * @subpackage Tokenminds_Academy/includes
 * @author     Delower Hossain <delowerjes@gmail.com>
 */
class Tokenminds_Academy_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
