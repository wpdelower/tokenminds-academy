<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://www.dbuggers.com
 * @since      1.0.0
 *
 * @package    Tokenminds_Academy
 * @subpackage Tokenminds_Academy/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Tokenminds_Academy
 * @subpackage Tokenminds_Academy/includes
 * @author     Delower Hossain <delowerjes@gmail.com>
 */
class Tokenminds_Academy_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'tokenminds-academy',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
